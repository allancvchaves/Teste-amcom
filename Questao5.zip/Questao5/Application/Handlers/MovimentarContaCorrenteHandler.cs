﻿using MediatR;
using Questao5.Application.Commands.Requests;
using Questao5.Application.Commands.Responses;
using Questao5.Domain.Entities;
using Questao5.Domain.Enumerators;
using Questao5.Domain.Exceptions;
using Questao5.Infrastructure.Database.CommandStore;
using Questao5.Infrastructure.Database.QueryStore;

namespace Questao5.Application.Handlers
{
    public class MovimentarContaCorrenteHandler : IRequestHandler<MovimentarContaCorrenteCommand, MovimentarContaCorrenteResponse>
    {
        private readonly MovimentarContaCorrenteCommandStore _commandStore;
        private readonly MovimentarContaCorrenteQueryStore _queryStore;

        public MovimentarContaCorrenteHandler(
            MovimentarContaCorrenteCommandStore commandStore,
            MovimentarContaCorrenteQueryStore queryStore)
        {
            _commandStore = commandStore;
            _queryStore = queryStore;
        }

        public async Task<MovimentarContaCorrenteResponse> Handle(MovimentarContaCorrenteCommand request, CancellationToken cancellationToken)
        {
            var resultadoExistente = await _queryStore.ObterResultadoPorChaveIdempotenciaAsync(request.IdRequisicao);
            if (resultadoExistente != null)
            {
                return new MovimentarContaCorrenteResponse
                {
                    IdMovimentacao = resultadoExistente,
                    Mensagem = "Movimentação já processada anteriormente."
                };
            }

            var contaCorrente = await _queryStore.ObterContaCorrentePorIdAsync(request.IdContaCorrente.ToString());
            if (contaCorrente is null)
            {
                throw new BusinessException("Conta não encontrada", "INVALID_ACCOUNT");
            }

            if (!contaCorrente.Ativo)
            {
                throw new BusinessException("Conta inativa", "INACTIVE_ACCOUNT");
            }

            if (request.Valor <= 0)
            {
                throw new BusinessException("Valor inválido", "INVALID_VALUE");
            }

            if (!request.TipoMovimento.Equals("C", StringComparison.OrdinalIgnoreCase)
                && !request.TipoMovimento.Equals("D", StringComparison.OrdinalIgnoreCase))
            {
                throw new BusinessException("Tipo de movimentação inválido", "INVALID_TYPE");
            }

            var movimentacao = new MovimentacaoContaCorrente
            {
                IdContaCorrente = request.IdContaCorrente.ToString(),
                Valor = request.Valor,
                IdRequisicao = request.IdRequisicao,
                DataMovimento = DateTime.Now,
                TipoMovimento = ConverterRequestParaTipoMovimento(request.TipoMovimento)
            };

            var id = await _commandStore.MovimentarAsync(movimentacao);

            return new MovimentarContaCorrenteResponse
            {
                IdMovimentacao = id.ToString(),
                Mensagem = "Movimentação realizada com sucesso."
            };
        }

        private TipoMovimento ConverterRequestParaTipoMovimento(string letraMovimento) => letraMovimento.Equals("C", StringComparison.OrdinalIgnoreCase) ? TipoMovimento.C : TipoMovimento.D;
    }
}
