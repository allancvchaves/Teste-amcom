﻿namespace Questao5.Application.Commands.Responses
{
    public class MovimentarContaCorrenteResponse
    {
        public string IdMovimentacao { get; set; }
        public string Mensagem { get; set; } = string.Empty;
    }
}
