﻿using Dapper;
using Questao5.Domain.Entities;
using Questao5.Infrastructure.Sqlite;

namespace Questao5.Infrastructure.Database.QueryStore
{
    public class MovimentarContaCorrenteQueryStore
    {
        private readonly DbConnectionFactory _dbConnectionFactory;

        public MovimentarContaCorrenteQueryStore(DbConnectionFactory dbConnectionFactory)
        {
            _dbConnectionFactory = dbConnectionFactory;
        }
        public async Task<ContaCorrente?> ObterContaCorrentePorIdAsync(string idContaCorrente)
        {
            const string sql = @"
            SELECT idcontacorrente as IdContaCorrente, numero, nome, ativo
            FROM contacorrente
            WHERE UPPER(idcontacorrente) = UPPER(@idContaCorrente);";

            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<ContaCorrente>(sql, new { idContaCorrente = idContaCorrente });
        }

        public async Task<string?> ObterResultadoPorChaveIdempotenciaAsync(Guid chaveIdempotencia)
        {
            const string sql = @"
            SELECT resultado
            FROM idempotencia
            WHERE chave_idempotencia = @ChaveIdempotencia;";

            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<string>(sql, new
            {
                ChaveIdempotencia = chaveIdempotencia.ToString()
            });
        }
    }
}
