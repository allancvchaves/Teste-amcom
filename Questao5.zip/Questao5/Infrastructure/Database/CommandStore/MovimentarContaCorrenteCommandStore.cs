﻿using Dapper;
using Questao5.Domain.Entities;
using Questao5.Infrastructure.Sqlite;

namespace Questao5.Infrastructure.Database.CommandStore
{
    public class MovimentarContaCorrenteCommandStore
    {
        private readonly DbConnectionFactory _dbConnectionFactory;

        public MovimentarContaCorrenteCommandStore(DbConnectionFactory dbConnectionFactory)
        {
            _dbConnectionFactory = dbConnectionFactory;
        }

        public async Task<int> MovimentarAsync(MovimentacaoContaCorrente movimentacao)
        {
            const string sql = @"
                INSERT INTO AccountMovements (idcontacorrente, valor, tipomovimento, datamovimento)
                VALUES (@IdContaCorrente, @Valor, @TipoMovimento, @DataMovimento);
                SELECT last_insert_rowid();";

            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<int>(sql, movimentacao);
        }

        public async Task SaveIdempotencyAsync(Guid chaveIdempotencia, string requisicao, string resultado)
        {
            const string sql = @"
            INSERT INTO idempotencia (chave_idempotencia, requisicao, resultado)
            VALUES (@ChaveIdempotencia, @Requisicao, @Resultado)
            ON CONFLICT(chave_idempotencia) DO NOTHING;";

            using var connection = _dbConnectionFactory.CreateConnection();
            await connection.ExecuteAsync(sql, new
            {
                ChaveIdempotencia = chaveIdempotencia.ToString(),
                Requisicao = requisicao,
                Resultado = resultado
            });
        }
    }
}
