﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Questao5.Application.Commands.Requests;
using Questao5.Domain.Exceptions;

namespace Questao5.Infrastructure.Services.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContaCorrenteController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ContaCorrenteController(IMediator mediator)
        {
            this._mediator = mediator;
        }

        [HttpPost("movimentar")]
        public async Task<IActionResult> MovimentarContaCorrente([FromBody] MovimentarContaCorrenteCommand command)
        {
            try
            {
                var result = await _mediator.Send(command);

                return Ok(new { result.IdMovimentacao});
            }
            catch (BusinessException ex)
            {
                return BadRequest(new { ex.Message, ErrorCore = ex.ErrorCode });
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
