﻿namespace Questao5.Domain.Enumerators
{
    public enum TipoMovimento
    {
        C, //Crédito
        D  //Débito
    }
}
